%__________________________________________________________________________
% violin.m - Simple violin plot using matlab default kernel density estimation
%
% Updates:
% v2: extended for accepting also cells of different length
% v3: 
%    - changed varargin to parameter - value list
%    - specification of x-axis vals possible now
% Last update: 09/2014
%__________________________________________________________________________
% This function creates violin plots based on kernel density estimation
% using ksdensity with default settings. Please be careful when comparing pdfs 
% estimated with different bandwidth!
%
% Differently to other boxplot functions, you may specify the x-position.
% This is particularly usefule when overlaying with other data / plots.
%__________________________________________________________________________
% 
% Please cite this function as:
% Hoffmann H, 2013: violin.m - Simple violin plot using matlab default kernel 
% density estimation. INRES (University of Bonn), Katzenburgweg 5, 53115 Germany.
% hhoffmann@uni-bonn.de
%
%__________________________________________________________________________
%
% Input:
% Y:     Data to be plotted, being either
% n x m matrix. A 'violin' is plotted for each column m, OR
% 1 x m Cellarry with elements being numerical colums of nx1 length.
%
% varargin:
% xlabel:    xlabel. Set either [] or in the form {'txt1','txt2','txt3',...}
% facecolor=[1 0.5 0]%FaceColor: Specify abbrev. or m x 3 matrix (e.g. [1 0 0])
% edgecolor='k'      %LineColor: Specify abbrev. (e.g. 'k' for black); set either [],'' or 'none' if the mean should not be plotted
% facealpha=0.5     %Alpha value (transparency)   
% mc='k'      %Color of the bars indicating the mean; set either [],'' or 'none' if the mean should not be plotted
% medc='r'    %Color of the bars indicating the median; set either [],'' or 'none' if the mean should not be plotted
% bw=[];      %Kernel bandwidth, prescribe if wanted. 
%            %If b is a single number, b will be applied to all estimates
%            %If b is an array of 1xm or mx1, b(i) will be applied to
%            column (i).
%
% Output:
% h: figure handle
% L: Legend handle
% MX: Means of groups
% MED: Medians of groups
% bw: bandwidth of kernel
%__________________________________________________________________________
%{
% example
close all
load iris_dataset
inputs = irisInputs;
targets = irisTargets;
sinaplot(inputs')


% Example1 (default):

disp('this example uses the statistical toolbox')
Y=[rand(1000,1),gamrnd(1,2,1000,1),normrnd(10,2,1000,1),gamrnd(10,0.1,1000,1)];
[h,L,MX,MED]=sinaplot(Y); 
ylabel('\Delta [yesno^{-2}]','FontSize',14)

%Example2 (specify facecolor, edgecolor, xlabel):

disp('this example uses the statistical toolbox')
Y=[rand(1000,1),gamrnd(1,2,1000,1),normrnd(10,2,1000,1),gamrnd(10,0.1,1000,1)];
violin(Y,'xlabel',{'a','b','c','d'},'facecolor',[1 1 0;0 1 0;.3 .3 .3;0 0.3 0.1],'edgecolor','b',...
'bw',0.3,...
'mc','k',...
'medc','r--')
ylabel('\Delta [yesno^{-2}]','FontSize',14)

%Example3 (specify x axis location):

disp('this example uses the statistical toolbox')
Y=[rand(1000,1),gamrnd(1,2,1000,1),normrnd(10,2,1000,1),gamrnd(10,0.1,1000,1)];
violin(Y,'x',[-1 .7 3.4 8.8],'facecolor',[1 1 0;0 1 0;.3 .3 .3;0 0.3 0.1],'edgecolor','none',...
'bw',0.3,'mc','k','medc','r-.')
axis([-2 10 -0.5 20])
ylabel('\Delta [yesno^{-2}]','FontSize',14)

%Example4 (Give data as cells with different n):

disp('this example uses the statistical toolbox')

Y{:,1}=rand(10,1);
Y{:,2}=rand(1000,1);
violin(Y,'facecolor',[1 1 0;0 1 0;.3 .3 .3;0 0.3 0.1],'edgecolor','none','bw',0.1,'mc','k','medc','r-.')
ylabel('\Delta [yesno^{-2}]','FontSize',14)
%}
%__________________________________________________________________________
%__________________________________________________________________________

function[h,L,MX,MED,bw]=sinaplot(Y,varargin)

 %defaults:
 %_____________________
 xL=[];
 fc=[1 0.5 0];
 lc='k';
 alp=0.5;
 alp=1;
 mc='k';
 mt='o';
 ms=1.5;
 lw=0.5;
 medc='r';
 b=[]; %bandwidth
 plotlegend=0; 
 plotmean=1;
 plotmedian=0;
 plotci=1;
 side='onesided';
 cip=0.95;
 width = 0.7;
 x = [];
 %_____________________

 %convert single columns to cells:
 if iscell(Y)==0
    Y = num2cell(Y,1);
 end
 
 %get additional parameters
 if isempty(find(strcmp(varargin,'xlabel')))==0
     xL = varargin{find(strcmp(varargin,'xlabel'))+1};
 end
 if isempty(find(strcmp(varargin,'facecolor')))==0
   fc = varargin{find(strcmp(varargin,'facecolor'))+1};
 end
 if isempty(find(strcmp(varargin,'edgecolor')))==0
     lc = varargin{find(strcmp(varargin,'edgecolor'))+1};
 end
 if isempty(find(strcmp(varargin,'MarkerSize')))==0
     ms = varargin{find(strcmp(varargin,'MarkerSize'))+1};
 end
 if isempty(find(strcmp(varargin,'MarkerType')))==0
     mt = varargin{find(strcmp(varargin,'MarkerType'))+1};
 end
 if isempty(find(strcmp(varargin,'LineWidth')))==0
     lw = varargin{find(strcmp(varargin,'LineWidth'))+1};
 end
 if isempty(find(strcmp(varargin,'facealpha')))==0
     alp = varargin{find(strcmp(varargin,'facealpha'))+1};
 end
 if isempty(find(strcmp(varargin,'side')))==0
     side = varargin{find(strcmp(varargin,'side'))+1};
 end
 if isempty(find(strcmp(varargin,'ci')))==0
     plotci = varargin{find(strcmp(varargin,'ci'))+1};
 end
 if isempty(find(strcmp(varargin,'cip')))==0
     cip = varargin{find(strcmp(varargin,'cip'))+1};
 end
 if isempty(find(strcmp(varargin,'mc')))==0
   if isempty(varargin{find(strcmp(varargin,'mc'))+1})==0
     mc = varargin{find(strcmp(varargin,'mc'))+1};
     plotmean = 1;
   else
     plotmean = 0;
   end
 end
 if isempty(find(strcmp(varargin,'width')))==0
     width = varargin{find(strcmp(varargin,'width'))+1};
 end

 if isempty(find(strcmp(varargin,'medc')))==0
    if isempty(varargin{find(strcmp(varargin,'medc'))+1})==0
     medc = varargin{find(strcmp(varargin,'medc'))+1};
     plotmedian = 1;
    else
     plotmedian = 0;
    end
 end
 if isempty(find(strcmp(varargin,'bw')))==0
     b = varargin{find(strcmp(varargin,'bw'))+1}
      if length(b)==1
         disp(['same bandwidth bw = ',num2str(b),' used for all cols'])
         b=repmat(b,size(Y,2),1);
      elseif length(b)~=size(Y,2)
         warning('length(b)~=size(Y,2)')
         error('please provide only one bandwidth or an array of b with same length as columns in the data set')
      end
 end
 if isempty(find(strcmp(varargin,'plotlegend')))==0
     plotlegend = varargin{find(strcmp(varargin,'plotlegend'))+1};
 end
 if isempty(find(strcmp(varargin,'x')))==0
     x = varargin{find(strcmp(varargin,'x'))+1};
 end
%  if isempty(find(strcmp(varargin,'groupcol')))==0
     if size(fc,1)==1
         fc=repmat(fc,size(Y,2),1);
     end
%  else
%      gc = varargin{find(strcmp(varargin,'groupcol'))+1};
%          %fc=repmat(fc,size(Y,2),1);
%          fc=gc;
%  end
 %-------------------------------------------------------------------------
 %-------------------------------------------------------------------------
 i=1;
 for i=1:size(Y,2)
     % remove nan values
     Y{i} = Y{i}(~isnan(Y{i}));
     
    if isempty(b)==0
     [f, u, bb]=ksdensity(Y{i},'bandwidth',b(i));
    elseif isempty(b)
     [f, u, bb]=ksdensity(Y{i});
    end
    
    f=f/max(f)*0.3; %normalize
    F(:,i)=f;
    U(:,i)=u;
    MED(:,i)=nanmedian(Y{i});
    MX(:,i)=nanmean(Y{i});
    bw(:,i)=bb;
    
 end
 %-------------------------------------------------------------------------
 %mp = get(0, 'MonitorPositions');
 %set(gcf,'Color','w','Position',[mp(end,1)+50 mp(end,2)+50 800 600])
 %-------------------------------------------------------------------------
 if isempty(x)
     x = zeros(size(Y,2));
     setX = 0;
 else
  setX = 1;
  if isempty(xL)==0
   disp('_________________________________________________________________')
   warning('Function is not designed for x-axis specification with string label')
   warning('when providing x, xlabel can be set later anyway')
   error('please provide either x or xlabel. not both.')
  end
 end
 %_________________________________________________________________________
 %%
 i=1;
 for i=i:size(Y,2)
     if plotci==1
         ci1=ciestim3(Y{i},1,cip,side);
     end
     if isempty(lc) == 1
         if setX == 0   
             h(i)=fill([F(:,i)+i;flipud(i-F(:,i))],[U(:,i);flipud(U(:,i))],fc(i,:),'FaceAlpha',alp,'EdgeColor','none');
         else
             h(i)=fill([F(:,i)+x(i);flipud(x(i)-F(:,i))],[U(:,i);flipud(U(:,i))],fc(i,:),'FaceAlpha',alp,'EdgeColor','none');
         end
     else
         if setX == 0
             %h(i)=fill([F(:,i)+i;flipud(i-F(:,i))],[U(:,i);flipud(U(:,i))],fc(i,:),'FaceAlpha',alp,'EdgeColor',lc);
             [a,bin]=histc(Y{i},U(:,i));
             norma = normal(a);
             binY = norma(bin);
%              h(i)=plot(((rand(length(bin),1)-0.5))*0.7.*binY+i,Y{i},mt,'markerfacecolor',[0.7,0.8,0.9],'markeredgecolor','none');
if strfind(mt,'none')
if length(Y{i})>3000
    rd = randsample(1:length(Y{i}),3000);
    h(i)=plot(((rand(3000,1)-0.5))*width.*binY(rd)+i,Y{i}(rd),'.','markerfacecolor','none','markeredgecolor','none','MarkerSize',ms,'LineWidth',lw);
    %              h(i)=plot(((rand(1000,1)-0.5))*0.7.*binY(rd)+i,Y{i}(rd),'.','Color',[0.7,0.8,0.9]);
else
    h(i)=plot(((rand(length(bin),1)-0.5))*width.*binY+i,Y{i},'.','markerfacecolor','none','markeredgecolor','none','MarkerSize',ms,'LineWidth',lw);
    %              h(i)=plot(((rand(length(bin),1)-0.5))*0.7.*binY+i,Y{i},'.','Color',[0.7,0.8,0.9]);
end
else
if length(Y{i})>3000
    rd = randsample(1:length(Y{i}),3000);
    h(i)=plot(((rand(3000,1)-0.5))*width.*binY(rd)+i,Y{i}(rd),mt,'markerfacecolor',fc(i,:),'markeredgecolor',lc,'MarkerSize',ms,'LineWidth',lw);
    %              h(i)=plot(((rand(1000,1)-0.5))*0.7.*binY(rd)+i,Y{i}(rd),'.','Color',[0.7,0.8,0.9]);
else
    %x_tmp = -abs(((rand(length(bin),1)-0.5))*width.*binY)+i;
    x_tmp = (((rand(length(bin),1)-0.5))*width.*binY)+i;
    h(i)=plot(x_tmp,Y{i},mt,'markerfacecolor',fc(i,:),'markeredgecolor',lc,'MarkerSize',ms,'LineWidth',lw);
    %              h(i)=plot(((rand(length(bin),1)-0.5))*0.7.*binY+i,Y{i},'.','Color',[0.7,0.8,0.9]);
end
end
%              h(i)=plot(((rand(length(bin),1)-0.5))*0.7.*binY+i,Y{i},mt,'markerfacecolor',[0.7,0.8,0.9],'markeredgecolor',[0,0,0]);
%         col{5}=[1,0.7,0.7];
%         col{4}=[0.7,1,1];
%         col{3}=[0.7,0.9,0.7];% green
%         col{2}=[0.4,0.4,0.4];
%         col{1}=[0.7,0.7,1];
         else
             h(i)=fill([F(:,i)+x(i);flipud(x(i)-F(:,i))],[U(:,i);flipud(U(:,i))],fc(i,:),'FaceAlpha',alp,'EdgeColor',lc);
         end
     end
     if plotci==1
         hold on
     plot([interp1(U(:,i),F(:,i)+i,MX(:,i)+ci1), interp1(flipud(U(:,i)),flipud(i-F(:,i)),MX(:,i)+ci1) ],[MX(:,i)+ci1 MX(:,i)+ci1],'r','LineWidth',lw);
     plot([interp1(U(:,i),F(:,i)+i,MX(:,i)-ci1), interp1(flipud(U(:,i)),flipud(i-F(:,i)),MX(:,i)-ci1) ],[MX(:,i)-ci1 MX(:,i)-ci1],'r','LineWidth',lw);
     end
     hold on
     if setX == 0
         if plotmean == 1
             p(1)=plot([interp1(U(:,i),F(:,i)+i,MX(:,i)), interp1(flipud(U(:,i)),flipud(i-F(:,i)),MX(:,i)) ],[MX(:,i) MX(:,i)],mc,'LineWidth',lw);
         end
         if plotmedian == 1
             p(2)=plot([interp1(U(:,i),F(:,i)+i,MED(:,i)), interp1(flipud(U(:,i)),flipud(i-F(:,i)),MED(:,i)) ],[MED(:,i) MED(:,i)],medc,'LineWidth',lw);
         end
     elseif setX == 1
         if plotmean == 1
             p(1)=plot([interp1(U(:,i),F(:,i)+i,MX(:,i))+x(i)-i, interp1(flipud(U(:,i)),flipud(i-F(:,i)),MX(:,i))+x(i)-i],[MX(:,i) MX(:,i)],mc,'LineWidth',lw);
         end
         if plotmedian == 1
             p(2)=plot([interp1(U(:,i),F(:,i)+i,MED(:,i))+x(i)-i, interp1(flipud(U(:,i)),flipud(i-F(:,i)),MED(:,i))+x(i)-i],[MED(:,i) MED(:,i)],medc,'LineWidth',lw);
         end
     end
 end
 %-------------------------------------------------------------------------
 if plotlegend==1 & plotmean==1 | plotlegend==1 & plotmedian==1
  
  if plotmean==1 & plotmedian==1
   L=legend([p(1) p(2)],'Mean','Median');
  elseif plotmean==0 & plotmedian==1
   L=legend([p(2)],'Median');
  elseif plotmean==1 & plotmedian==0
   L=legend([p(1)],'Mean');
  end 
  
  set(L,'box','off','FontSize',14)
 else
    L=[];
 end
 %-------------------------------------------------------------------------
 axis([0.5 size(Y,2)+0.5, min(U(:)) max(U(:))]);
 %-------------------------------------------------------------------------
 xL2={''};
 i=1;
 for i=1:size(xL,2)
  xL2=[xL2,xL{i},{''}];
 end
 set(gca,'TickLength',[0 0],'FontSize',12)
 box on
 
 if isempty(xL)==0
     set(gca,'XtickLabel',xL2)
 end
 %-------------------------------------------------------------------------
end %of function